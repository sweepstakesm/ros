! function(e) {
    function t(t) {
        for (var n, o, i = t[0], a = t[1], u = 0, s = []; u < i.length; u++) o = i[u], r[o] && s.push(r[o][0]), r[o] = 0;
        for (n in a) Object.prototype.hasOwnProperty.call(a, n) && (e[n] = a[n]);
        for (c && c(t); s.length;) s.shift()()
    }
    var n = {},
        r = {
            0: 0
        };

    function o(t) {
        if (n[t]) return n[t].exports;
        var r = n[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(r.exports, r, r.exports, o), r.l = !0, r.exports
    }
    o.e = function(e) {
        var t = [],
            n = r[e];
        if (0 !== n)
            if (n) t.push(n[2]);
            else {
                var i = new Promise((function(t, o) {
                    n = r[e] = [t, o]
                }));
                t.push(n[2] = i);
                var a, u = document.createElement("script");
                u.charset = "utf-8", u.timeout = 120, o.nc && u.setAttribute("nonce", o.nc), u.src = function(e) {
                    return o.p + "" + ({
                        1: "vendors~rollbar.noconflict.umd.min"
                    } [e] || e) + ".js"
                }(e);
                var c = new Error;
                a = function(t) {
                    u.onerror = u.onload = null, clearTimeout(s);
                    var n = r[e];
                    if (0 !== n) {
                        if (n) {
                            var o = t && ("load" === t.type ? "missing" : t.type),
                                i = t && t.target && t.target.src;
                            c.message = "Loading chunk " + e + " failed.\n(" + o + ": " + i + ")", c.name = "ChunkLoadError", c.type = o, c.request = i, n[1](c)
                        }
                        r[e] = void 0
                    }
                };
                var s = setTimeout((function() {
                    a({
                        type: "timeout",
                        target: u
                    })
                }), 12e4);
                u.onerror = u.onload = a, document.head.appendChild(u)
            } return Promise.all(t)
    }, o.m = e, o.c = n, o.d = function(e, t, n) {
        o.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, o.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, o.t = function(e, t) {
        if (1 & t && (e = o(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (o.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) o.d(n, r, function(t) {
                return e[t]
            }.bind(null, r));
        return n
    }, o.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return o.d(t, "a", t), t
    }, o.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, o.p = "https://static.zdassets.com/ekr/", o.oe = function(e) {
        throw console.error(e), e
    };
    var i = window.zEWebpackACJsonp = window.zEWebpackACJsonp || [],
        a = i.push.bind(i);
    i.push = t, i = i.slice();
    for (var u = 0; u < i.length; u++) t(i[u]);
    var c = a;
    o(o.s = 7)
}([function(e, t, n) {
    "use strict";
    (function(e) {
        var r = n(3),
            o = setTimeout;

        function i(e) {
            return Boolean(e && e.length)
        }

        function a() {}

        function u(e) {
            if (!(this instanceof u)) throw new TypeError("Promises must be constructed via new");
            if ("function" != typeof e) throw new TypeError("not a function");
            this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], d(e, this)
        }

        function c(e, t) {
            for (; 3 === e._state;) e = e._value;
            0 !== e._state ? (e._handled = !0, u._immediateFn((function() {
                var n = 1 === e._state ? t.onFulfilled : t.onRejected;
                if (null !== n) {
                    var r;
                    try {
                        r = n(e._value)
                    } catch (e) {
                        return void f(t.promise, e)
                    }
                    s(t.promise, r)
                } else(1 === e._state ? s : f)(t.promise, e._value)
            }))) : e._deferreds.push(t)
        }

        function s(e, t) {
            try {
                if (t === e) throw new TypeError("A promise cannot be resolved with itself.");
                if (t && ("object" == typeof t || "function" == typeof t)) {
                    var n = t.then;
                    if (t instanceof u) return e._state = 3, e._value = t, void l(e);
                    if ("function" == typeof n) return void d((r = n, o = t, function() {
                        r.apply(o, arguments)
                    }), e)
                }
                e._state = 1, e._value = t, l(e)
            } catch (t) {
                f(e, t)
            }
            var r, o
        }

        function f(e, t) {
            e._state = 2, e._value = t, l(e)
        }

        function l(e) {
            2 === e._state && 0 === e._deferreds.length && u._immediateFn((function() {
                e._handled || u._unhandledRejectionFn(e._value)
            }));
            for (var t = 0, n = e._deferreds.length; t < n; t++) c(e, e._deferreds[t]);
            e._deferreds = null
        }

        function p(e, t, n) {
            this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.promise = n
        }

        function d(e, t) {
            var n = !1;
            try {
                e((function(e) {
                    n || (n = !0, s(t, e))
                }), (function(e) {
                    n || (n = !0, f(t, e))
                }))
            } catch (e) {
                if (n) return;
                n = !0, f(t, e)
            }
        }
        u.prototype.catch = function(e) {
            return this.then(null, e)
        }, u.prototype.then = function(e, t) {
            var n = new this.constructor(a);
            return c(this, new p(e, t, n)), n
        }, u.prototype.finally = r.a, u.all = function(e) {
            return new u((function(t, n) {
                if (!i(e)) return n(new TypeError("Promise.all accepts an array"));
                var r = Array.prototype.slice.call(e);
                if (0 === r.length) return t([]);
                var o = r.length;

                function a(e, i) {
                    try {
                        if (i && ("object" == typeof i || "function" == typeof i)) {
                            var u = i.then;
                            if ("function" == typeof u) return void u.call(i, (function(t) {
                                a(e, t)
                            }), n)
                        }
                        r[e] = i, 0 == --o && t(r)
                    } catch (e) {
                        n(e)
                    }
                }
                for (var u = 0; u < r.length; u++) a(u, r[u])
            }))
        }, u.resolve = function(e) {
            return e && "object" == typeof e && e.constructor === u ? e : new u((function(t) {
                t(e)
            }))
        }, u.reject = function(e) {
            return new u((function(t, n) {
                n(e)
            }))
        }, u.race = function(e) {
            return new u((function(t, n) {
                if (!i(e)) return n(new TypeError("Promise.race accepts an array"));
                for (var r = 0, o = e.length; r < o; r++) u.resolve(e[r]).then(t, n)
            }))
        }, u._immediateFn = "function" == typeof e && function(t) {
            e(t)
        } || function(e) {
            o(e, 0)
        }, u._unhandledRejectionFn = function(e) {
            "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
        }, t.a = u
    }).call(this, n(4).setImmediate)
}, function(e, t) {
    function n(e) {
        var t = document.createElement("a");
        return t.href = e, t.search.split("?")[1] || ""
    }
    e.exports = {
        getQueryParamsString: n,
        parseUrlParams: function(e) {
            var t = n(e);
            return "" === t ? {} : t.split("&").reduce((function(e, t) {
                var n = t.split("=");
                return e[n[0]] = decodeURIComponent(n[1]), e
            }), {})
        },
        loadScript: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {},
                n = document.createElement("script");
            n.type = "text/javascript", n.onerror = function() {
                t(new Error("Script failed to load"))
            }, n.readyState ? n.onreadystatechange = function() {
                "loaded" !== n.readyState && "complete" !== n.readyState || (n.onreadystatechange = null, t())
            } : n.onload = function() {
                t()
            }, n.src = e, document.getElementsByTagName("head")[0].appendChild(n)
        }
    }
}, function(e, t) {
    var n;
    n = function() {
        return this
    }();
    try {
        n = n || new Function("return this")()
    } catch (e) {
        "object" == typeof window && (n = window)
    }
    e.exports = n
}, function(e, t, n) {
    "use strict";
    t.a = function(e) {
        var t = this.constructor;
        return this.then((function(n) {
            return t.resolve(e()).then((function() {
                return n
            }))
        }), (function(n) {
            return t.resolve(e()).then((function() {
                return t.reject(n)
            }))
        }))
    }
}, function(e, t, n) {
    (function(e) {
        var r = void 0 !== e && e || "undefined" != typeof self && self || window,
            o = Function.prototype.apply;

        function i(e, t) {
            this._id = e, this._clearFn = t
        }
        t.setTimeout = function() {
            return new i(o.call(setTimeout, r, arguments), clearTimeout)
        }, t.setInterval = function() {
            return new i(o.call(setInterval, r, arguments), clearInterval)
        }, t.clearTimeout = t.clearInterval = function(e) {
            e && e.close()
        }, i.prototype.unref = i.prototype.ref = function() {}, i.prototype.close = function() {
            this._clearFn.call(r, this._id)
        }, t.enroll = function(e, t) {
            clearTimeout(e._idleTimeoutId), e._idleTimeout = t
        }, t.unenroll = function(e) {
            clearTimeout(e._idleTimeoutId), e._idleTimeout = -1
        }, t._unrefActive = t.active = function(e) {
            clearTimeout(e._idleTimeoutId);
            var t = e._idleTimeout;
            t >= 0 && (e._idleTimeoutId = setTimeout((function() {
                e._onTimeout && e._onTimeout()
            }), t))
        }, n(5), t.setImmediate = "undefined" != typeof self && self.setImmediate || void 0 !== e && e.setImmediate || this && this.setImmediate, t.clearImmediate = "undefined" != typeof self && self.clearImmediate || void 0 !== e && e.clearImmediate || this && this.clearImmediate
    }).call(this, n(2))
}, function(e, t, n) {
    (function(e, t) {
        ! function(e, n) {
            "use strict";
            if (!e.setImmediate) {
                var r, o, i, a, u, c = 1,
                    s = {},
                    f = !1,
                    l = e.document,
                    p = Object.getPrototypeOf && Object.getPrototypeOf(e);
                p = p && p.setTimeout ? p : e, "[object process]" === {}.toString.call(e.process) ? r = function(e) {
                    t.nextTick((function() {
                        h(e)
                    }))
                } : ! function() {
                    if (e.postMessage && !e.importScripts) {
                        var t = !0,
                            n = e.onmessage;
                        return e.onmessage = function() {
                            t = !1
                        }, e.postMessage("", "*"), e.onmessage = n, t
                    }
                }() ? e.MessageChannel ? ((i = new MessageChannel).port1.onmessage = function(e) {
                    h(e.data)
                }, r = function(e) {
                    i.port2.postMessage(e)
                }) : l && "onreadystatechange" in l.createElement("script") ? (o = l.documentElement, r = function(e) {
                    var t = l.createElement("script");
                    t.onreadystatechange = function() {
                        h(e), t.onreadystatechange = null, o.removeChild(t), t = null
                    }, o.appendChild(t)
                }) : r = function(e) {
                    setTimeout(h, 0, e)
                } : (a = "setImmediate$" + Math.random() + "$", u = function(t) {
                    t.source === e && "string" == typeof t.data && 0 === t.data.indexOf(a) && h(+t.data.slice(a.length))
                }, e.addEventListener ? e.addEventListener("message", u, !1) : e.attachEvent("onmessage", u), r = function(t) {
                    e.postMessage(a + t, "*")
                }), p.setImmediate = function(e) {
                    "function" != typeof e && (e = new Function("" + e));
                    for (var t = new Array(arguments.length - 1), n = 0; n < t.length; n++) t[n] = arguments[n + 1];
                    var o = {
                        callback: e,
                        args: t
                    };
                    return s[c] = o, r(c), c++
                }, p.clearImmediate = d
            }

            function d(e) {
                delete s[e]
            }

            function h(e) {
                if (f) setTimeout(h, 0, e);
                else {
                    var t = s[e];
                    if (t) {
                        f = !0;
                        try {
                            ! function(e) {
                                var t = e.callback,
                                    n = e.args;
                                switch (n.length) {
                                    case 0:
                                        t();
                                        break;
                                    case 1:
                                        t(n[0]);
                                        break;
                                    case 2:
                                        t(n[0], n[1]);
                                        break;
                                    case 3:
                                        t(n[0], n[1], n[2]);
                                        break;
                                    default:
                                        t.apply(void 0, n)
                                }
                            }(t)
                        } finally {
                            d(e), f = !1
                        }
                    }
                }
            }
        }("undefined" == typeof self ? void 0 === e ? this : e : self)
    }).call(this, n(2), n(6))
}, function(e, t) {
    var n, r, o = e.exports = {};

    function i() {
        throw new Error("setTimeout has not been defined")
    }

    function a() {
        throw new Error("clearTimeout has not been defined")
    }

    function u(e) {
        if (n === setTimeout) return setTimeout(e, 0);
        if ((n === i || !n) && setTimeout) return n = setTimeout, setTimeout(e, 0);
        try {
            return n(e, 0)
        } catch (t) {
            try {
                return n.call(null, e, 0)
            } catch (t) {
                return n.call(this, e, 0)
            }
        }
    }! function() {
        try {
            n = "function" == typeof setTimeout ? setTimeout : i
        } catch (e) {
            n = i
        }
        try {
            r = "function" == typeof clearTimeout ? clearTimeout : a
        } catch (e) {
            r = a
        }
    }();
    var c, s = [],
        f = !1,
        l = -1;

    function p() {
        f && c && (f = !1, c.length ? s = c.concat(s) : l = -1, s.length && d())
    }

    function d() {
        if (!f) {
            var e = u(p);
            f = !0;
            for (var t = s.length; t;) {
                for (c = s, s = []; ++l < t;) c && c[l].run();
                l = -1, t = s.length
            }
            c = null, f = !1,
                function(e) {
                    if (r === clearTimeout) return clearTimeout(e);
                    if ((r === a || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                    try {
                        r(e)
                    } catch (t) {
                        try {
                            return r.call(null, e)
                        } catch (t) {
                            return r.call(this, e)
                        }
                    }
                }(e)
        }
    }

    function h(e, t) {
        this.fun = e, this.array = t
    }

    function y() {}
    o.nextTick = function(e) {
        var t = new Array(arguments.length - 1);
        if (arguments.length > 1)
            for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
        s.push(new h(e, t)), 1 !== s.length || f || u(d)
    }, h.prototype.run = function() {
        this.fun.apply(null, this.array)
    }, o.title = "browser", o.browser = !0, o.env = {}, o.argv = [], o.version = "", o.versions = {}, o.on = y, o.addListener = y, o.once = y, o.off = y, o.removeListener = y, o.removeAllListeners = y, o.emit = y, o.prependListener = y, o.prependOnceListener = y, o.listeners = function(e) {
        return []
    }, o.binding = function(e) {
        throw new Error("process.binding is not supported")
    }, o.cwd = function() {
        return "/"
    }, o.chdir = function(e) {
        throw new Error("process.chdir is not supported")
    }, o.umask = function() {
        return 0
    }
}, function(e, t, n) {
    "use strict";
    n.r(t);
    var r = n(0);

    function o(e) {
        return new r.a((function(t, n) {
            var r = new XMLHttpRequest;
            r.open("GET", e, !0), r.responseType = "json", r.onload = function() {
                if (200 === r.status) {
                    var e = r.response,
                        o = "string" == typeof e ? JSON.parse(e) : e;
                    t(o)
                } else n(Error(r.statusText))
            }, r.onerror = function() {
                n(Error("Network error"))
            }, r.send()
        }))
    }

    function i(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }
    var a = function e() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            i(this, e), this.message = t, this.props = n, this.error = Error(this.message), this.isUserError = r, this.rollbarFingerprint = this.message
        },
        u = {},
        c = {},
        s = {};

    function f(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }
    var l = function() {
        function e(t, n) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.name = t.name, this.id = t.id, this.features = t.features, this.win = n, this.doc = n.document
        }
        var t, n, i;
        return t = e, (n = [{
            key: "ready",
            value: function() {
                var e = this;
                return new r.a((function(t, n) {
                    e.createIframeElement().then((function(r) {
                        r.addEventListener("load", (function() {
                            var i = r.contentWindow;
                            i && i.document ? (i.ACFetch = o, t(i.document)) : n(e.error())
                        })), r.src = "about:blank", e.doc.body.appendChild(r)
                    }))
                }))
            }
        }, {
            key: "injectMetadata",
            value: function(e, t) {
                var n, r, o;
                e && (e.zendesk = (n = {}, r = this.name, o = {
                    id: this.id,
                    features: this.features
                }, r in n ? Object.defineProperty(n, r, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[r] = o, n), e.zEQueue = t)
            }
        }, {
            key: "injectAssets",
            value: function(e, t) {
                var n = this;
                if (e) {
                    var r = e.getElementsByTagName("head")[0];
                    t.scripts.forEach((function(t) {
                        r.appendChild(n.createScriptElement(e, t.src))
                    }))
                }
            }
        }, {
            key: "parentDocumentReady",
            value: function() {
                var e = this;
                return new r.a((function(t, n) {
                    "loading" !== e.doc.readyState && e.doc.body ? t() : e.doc.addEventListener("DOMContentLoaded", (function() {
                        e.doc.body ? t() : n(new a("host page document.body not available"))
                    }))
                }))
            }
        }, {
            key: "createIframeElement",
            value: function() {
                var e = this;
                return this.parentDocumentReady().then((function() {
                    var t = e.doc.createElement("iframe");
                    return t.dataset.product = e.name, t.title = "No content", t.role = "presentation", t.tabIndex = -1, t.setAttribute("aria-hidden", !0), t.style.cssText = "width: 0; height: 0; border: 0; position: absolute; top: -9999px", t
                }))
            }
        }, {
            key: "createScriptElement",
            value: function(e, t) {
                if (!e) return null;
                var n = e.createElement("script");
                return n.type = "text/javascript", n.src = t, n
            }
        }, {
            key: "error",
            value: function() {
                var e = {
                    product: this.name,
                    id: this.id,
                    features: this.features
                };
                return new a("iframe document not available to load product", e)
            }
        }]) && f(t.prototype, n), i && f(t, i), e
    }();

    function p(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }
    var d = function() {
            function e(t, n) {
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, e), this.product = t, this.productIframe = new l(this.product, n)
            }
            var t, n, o;
            return t = e, (n = [{
                key: "getProductAssets",
                value: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    return e ? s[this.product.name].assets : this.product.assets
                }
            }, {
                key: "load",
                value: function(e, t) {
                    var n = this;
                    return this.productIframe.ready().then((function(r) {
                        n.productIframe.injectMetadata(r, t), n.productIframe.injectAssets(r, e)
                    })).catch((function() {
                        return r.a.reject(n.loadProductError())
                    }))
                }
            }, {
                key: "loadProductError",
                value: function() {
                    var e = this.product,
                        t = e.name,
                        n = e.id,
                        r = e.features;
                    return new a("failed to load product", {
                        product: t,
                        id: n,
                        features: r
                    })
                }
            }]) && p(t.prototype, n), o && p(t, o), e
        }(),
        h = n(1);

    function y(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }
    var m = function() {
        function e(t, n) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.zopimKey = t, this.win = n, this.doc = n.document
        }
        var t, n, o;
        return t = e, (n = [{
            key: "getProductAssets",
            value: function() {
                return {
                    zopimSrc: "".concat("https://v2.zopim.com/w", "?").concat(this.zopimKey)
                }
            }
        }, {
            key: "load",
            value: function(e) {
                return new r.a((function(t, n) {
                    try {
                        Object(h.loadScript)(e.zopimSrc), t()
                    } catch (e) {
                        n(e)
                    }
                }))
            }
        }]) && y(t.prototype, n), o && y(t, o), e
    }();

    function v(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }
    var b = function() {
        function e(t, n) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.version = this.getVersion(t), this.baseUrl = "".concat("https://ekr.zdassets.com/", "compose/").concat(n)
        }
        var t, n, r;
        return t = e, (n = [{
            key: "resolveComposeUrl",
            value: function() {
                var e = this.baseUrl;
                return this.version && (e = this.baseUrl + "?".concat(this.getSerializedVersionQueryParam()), this.displayWarning()), decodeURI(e)
            }
        }, {
            key: "displayWarning",
            value: function() {
                console.warn("You are loading ".concat(this.version.name, " version ").concat(this.version.sha))
            }
        }, {
            key: "getSerializedVersionQueryParam",
            value: function() {
                return "".concat("__zE_ac_version", "=").concat(this.version.name, "/").concat(this.version.sha)
            }
        }, {
            key: "getVersion",
            value: function(e) {
                var t = Object(h.parseUrlParams)(e.location.href).__zE_ac_version;
                if (t) {
                    var n = t.split("/");
                    if (this.validSha(n[1])) return {
                        name: n[0],
                        sha: n[1]
                    }
                }
            }
        }, {
            key: "validSha",
            value: function(e) {
                return /^[0-9a-f]+$/.test(e)
            }
        }]) && v(t.prototype, n), r && v(t, r), e
    }();

    function g(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }
    var w = function() {
        function e(t) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.snippet = t
        }
        var t, n, i;
        return t = e, (n = [{
            key: "getProducts",
            value: function(e) {
                var t = this,
                    n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return new r.a((function(r, i) {
                    var a = t.snippet.getParentWindow();
                    n ? (a.zEACLoaded = !0, a.$zopim ? r(c.products) : r(u.products)) : o(new b(a, e).resolveComposeUrl()).then((function(e) {
                        var t = e.products;
                        a.zEACLoaded = !0, r(t)
                    })).catch((function() {
                        return i(t.error(e))
                    }))
                }))
            }
        }, {
            key: "loadProducts",
            value: function(e) {
                var t = this,
                    n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return e.map((function(e) {
                    var o = e.getProductAssets(n);
                    return e.load(o, t.snippet.getZEQueue()).catch((function(e) {
                        return r.a.reject(e)
                    }))
                }))
            }
        }, {
            key: "getProductLoaders",
            value: function(e) {
                var t = this.snippet.getParentWindow();
                return e.map((function(e) {
                    return "zopim_chat" === e.name ? new m(e.id, t) : new d(e, t)
                }))
            }
        }, {
            key: "error",
            value: function(e) {
                return new a("compose request failed", {
                    key: e
                })
            }
        }]) && g(t.prototype, n), i && g(t, i), e
    }();

    function _(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }
    var E = function() {
        function e(t) {
            ! function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
            }(this, e), this.win = t, this.doc = t.document
        }
        var t, n, o;
        return t = e, (n = [{
            key: "getKey",
            value: function() {
                return new r.a((function(e, t) {
                    return t(new a("Key is missing from snippet", {}, !0))
                }))
            }
        }, {
            key: "getZEQueue",
            value: function() {
                return null
            }
        }, {
            key: "getParentWindow",
            value: function() {
                return this.win
            }
        }]) && _(t.prototype, n), o && _(t, o), e
    }();

    function k(e) {
        return (k = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function T(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function j(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }

    function P(e, t) {
        return !t || "object" !== k(t) && "function" != typeof t ? function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }(e) : t
    }

    function O(e) {
        return (O = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function S(e, t) {
        return (S = Object.setPrototypeOf || function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }
    var z = function(e) {
        function t() {
            return T(this, t), P(this, O(t).apply(this, arguments))
        }
        var n, i, u;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), t && S(e, t)
        }(t, e), n = t, (i = [{
            key: "getKey",
            value: function() {
                var e = this;
                return new r.a((function(t, n) {
                    var r = e.doc.zendeskHost;
                    return r ? e._isHostMapped(r) ? o("https://".concat(r, "/embeddable/zendesk_host")).then((function(e) {
                        return t("web_widget/".concat(e.zendesk_host))
                    })).catch((function(e) {
                        return n(new a(e.message))
                    })) : t("web_widget/".concat(r)) : n(Error("Zendesk host is not defined"))
                }))
            }
        }, {
            key: "getZEQueue",
            value: function() {
                return this.doc.zEQueue
            }
        }, {
            key: "getParentWindow",
            value: function() {
                return this.win.parent
            }
        }, {
            key: "_isHostMapped",
            value: function(e) {
                return -1 === e.indexOf(".zendesk.com") && -1 === e.indexOf(".zendesk-staging.com")
            }
        }]) && j(n.prototype, i), u && j(n, u), t
    }(E);

    function I(e) {
        return (I = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function C(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function x(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }

    function A(e, t) {
        return !t || "object" !== I(t) && "function" != typeof t ? function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }(e) : t
    }

    function M(e) {
        return (M = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function L(e, t) {
        return (L = Object.setPrototypeOf || function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }
    var R = function(e) {
        function t() {
            return C(this, t), A(this, M(t).apply(this, arguments))
        }
        var n, o, i;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), t && L(e, t)
        }(t, e), n = t, i = [{
            key: "isSnippetPresent",
            value: function(e) {
                return e.document.getElementById("ze-snippet")
            }
        }], (o = [{
            key: "getKey",
            value: function() {
                var e = this;
                return new r.a((function(t, n) {
                    var r = e._getScript(e.win.zE);
                    if (r) {
                        var o = Object(h.parseUrlParams)(r.src);
                        if (o && o.key) return t(o.key)
                    }
                    return n(new a("Key is missing from snippet", {}, !0))
                }))
            }
        }, {
            key: "getZEQueue",
            value: function() {
                return this.win.zE._
            }
        }, {
            key: "_getScript",
            value: function(e) {
                var n = t.isSnippetPresent(this.win);
                return n || (e && e.s ? e.s : void 0)
            }
        }]) && x(n.prototype, o), i && x(n, i), t
    }(E);

    function F(e) {
        return (F = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function U(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function Q(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
        }
    }

    function K(e, t) {
        return !t || "object" !== F(t) && "function" != typeof t ? function(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e
        }(e) : t
    }

    function W(e) {
        return (W = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
            return e.__proto__ || Object.getPrototypeOf(e)
        })(e)
    }

    function $(e, t) {
        return ($ = Object.setPrototypeOf || function(e, t) {
            return e.__proto__ = t, e
        })(e, t)
    }
    var B = function(e) {
        function t() {
            return U(this, t), K(this, W(t).apply(this, arguments))
        }
        var n, o, i;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), t && $(e, t)
        }(t, e), n = t, i = [{
            key: "getScriptSrc",
            value: function(e) {
                if (e.$zopim && e.$zopim.s) return e.$zopim.s.src;
                for (var t, n = document.getElementsByTagName("script"), r = /.*zopim.(com|net|org)\//, o = 0, i = n.length; o < i; o++)
                    if (t = n[o].src || "", r.test(t)) return t
            }
        }, {
            key: "isSnippetPresent",
            value: function(e) {
                return !!t.getScriptSrc(e)
            }
        }], (o = [{
            key: "getKey",
            value: function() {
                var e = this;
                return new r.a((function(n, r) {
                    var o = Object(h.getQueryParamsString)(t.getScriptSrc(e.win));
                    return n("zopim_chat/".concat(o))
                }))
            }
        }]) && Q(n.prototype, o), i && Q(n, i), t
    }(E);
    var N = null,
        H = {
            enabled: !window.zESettings || void 0 === window.zESettings.errorReporting || Boolean(window.zESettings.errorReporting),
            accessToken: "4e3c5f67126a4e5a8bbe16cf479b1a81",
            endpoint: "https://rollbar-eu.zendesk.com/api/1/item/",
            captureUncaught: !1,
            captureUnhandledRejections: !1,
            checkIgnore: function(e, t, n) {
                return !(0 === Math.floor(1e3 * Math.random()))
            },
            transform: function(e) {
                var t = (((e.body || {}).message || {}).extra || {}).rollbarFingerprint;
                t && (e.fingerprint = t, e.title = "AssetComposerError: ".concat(e.body.message.extra.message))
            },
            payload: {
                environment: "production"
            }
        },
        Z = function() {
            return new r.a((function(e) {
                N ? e(N) : n.e(1).then(n.t.bind(null, 8, 7)).then((function(t) {
                    var n = t.default;
                    N = new n(H), e(N)
                }))
            }))
        };

    function D(e) {
        return e && e instanceof a ? Z().then((function(t) {
            t.warning(e.message, e), window.console && e.isUserError && window.console.error(e.message)
        })) : Z().then((function(t) {
            t.error(e)
        }))
    }! function() {
        try {
            if ("function" != typeof window.zE) {
                var e = function() {
                    var e = [],
                        t = function() {
                            e.push(arguments)
                        };
                    return t._ = e, t.t = Date.now(), t
                }();
                window.zE = e, window.zEmbed = e
            }
            if (window.zEACLoaded) return;
            var t = function(e) {
                    return R.isSnippetPresent(e) ? new R(e) : e.document.zendeskHost && e.document.zEQueue ? new z(e) : B.isSnippetPresent(e) ? new B(e) : new R(e)
                }(window),
                n = new w(t);
            t.getKey().then((function(e) {
                return n.getProducts(e, !1)
            })).then((function(e) {
                return r.a.all(n.loadProducts(n.getProductLoaders(e), !1))
            })).catch((function(e) {
                return D(e)
            }))
        } catch (e) {
            D(e)
        }
    }()
}]);